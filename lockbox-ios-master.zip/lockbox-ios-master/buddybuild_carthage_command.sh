#!/bin/bash

carthage bootstrap --platform iOS --verbose
