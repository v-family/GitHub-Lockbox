// +build !windows

package main

func setManifestRegistry(targetEnv, manifestPath string) error {
	return nil
}
