//
//  LoginViewController.m
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/17/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import "LoginViewController.h"
#import "SuccessfulLoginViewController.h"
#import "ErrorViewController.h"
#import "AppDelegate.h"

@interface LoginViewController () {
    __weak IBOutlet SPSDKLoginButton *sdkLoginButton;
}

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    customLoginButton.layer.cornerRadius = 4; // this value vary as per your desire
    customLoginButton.clipsToBounds = YES;
    //Set delegate method for SPSdkManager
//    [SPSdkManager sharedInstance].delegate = self;
    
    
//     Add a SaasPass-branded login button to your app
//    SPSDKLoginButton *loginButton = [[SPSDKLoginButton alloc] initWithFrame:CGRectMake(60, 440, 200, 50)];
//     Optional: Place the button in the center of your view.
//    loginButton.center = self.view.center;
//    [loginButton setFrame:CGRectMake(60, 440, 200, 40)];
//    [self.view addSubview:loginButton];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)performShortcutAction:(NSString *)type {
    if ([type isEqualToString:SHORTCUTITEMTYPE_SPLOGIN]) {
        [sdkLoginButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)loginButton:(SPSDKLoginButton *)loginButton didCompleteWithResult:(SPSDKLoginResult *)result withError:(NSError *)error
{
    if (error) {
        //Process error
        ErrorViewController *errorViewController =(ErrorViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"ErrorViewController"];
        errorViewController.errorMsg = error.localizedDescription;
        errorViewController.errorCode = error.code;
        [self.navigationController pushViewController:errorViewController animated:YES];
    } else if (result.isCanceled) {
        //Cancelled
        ErrorViewController *errorViewController =(ErrorViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"ErrorViewController"];
        errorViewController.errorMsg = @"Cancelled by user.";
        [self.navigationController pushViewController:errorViewController animated:YES];
    } else {
        //Logged in
        UIViewController *controller =  [self.storyboard instantiateViewControllerWithIdentifier:@"SuccessfulLoginViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        [APP_DELEGATE setLoggedIn:YES];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
