//
//  ErrorViewController.m
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/18/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import "ErrorViewController.h"
#import <SaasPassSDK/SDKErrors.h>

@implementation ErrorViewController {
    __weak IBOutlet NSLayoutConstraint *btnDownloadHeighConstrait;
}

@synthesize errorMsg, errorCode;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    btnGoBack.layer.cornerRadius = 4; // this value vary as per your desire
    btnGoBack.clipsToBounds = YES;
    btnDownload.layer.cornerRadius = 4; // this value vary as per your desire
    btnDownload.clipsToBounds = YES;
    
    if (errorCode == SPSdkErrorCodeSPAppNotFound) {
        lblErrorMessage.text = @"SAASPASS Application not installed on the device.";
        btnDownload.hidden = NO;
    } else {
        btnDownloadHeighConstrait.constant = 0;
        btnDownload.hidden = YES;
        lblErrorMessage.text = errorMsg;
    }
    [lblErrorMessage sizeToFit];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)download:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-apps://itunes.apple.com/app/saaspass-two-factor-authentication/id849132027?mt=8"]];
}

-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setErrorMessage:(NSString*)errorMessage
{
    lblErrorMessage.text = errorMessage;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
