//
//  AppDelegate.h
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/17/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SaasPassSDK/SaasPassSDK.h>

#define APP_DELEGATE (AppDelegate *)[[UIApplication sharedApplication] delegate]

#define SHORTCUTITEMTYPE_SPLOGIN                        @"spLogin"

@interface AppDelegate : UIResponder <UIApplicationDelegate, SPSDKManagerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic) BOOL loggedIn;

@end

