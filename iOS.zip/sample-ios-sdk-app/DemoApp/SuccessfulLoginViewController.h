//
//  SuccessfulLoginViewController.h
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/17/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuccessfulLoginViewController : UIViewController

@end
