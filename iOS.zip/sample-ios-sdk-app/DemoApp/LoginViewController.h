//
//  LoginViewController.h
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/17/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SaasPassSDK/SaasPassSDK.h>

@interface LoginViewController : UIViewController<SPSDKLoginButtonDelegate>
{
    IBOutlet NSLayoutConstraint *top;
    IBOutlet UIImageView *imgLogo;
    IBOutlet UIButton *customLoginButton;
}

- (void)performShortcutAction:(NSString *)type;

@end

