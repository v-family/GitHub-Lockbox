//
//  SPSDKManager.h
//  SaasPassSDK
//
//  Created by Ljupco Gjorgjiev on 10/2/15.
//  Copyright (c) 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SPSDKLoginResult.h"
#import "SDKErrors.h"

typedef void(^SPSDKLoginResultHandler)(SPSDKLoginResult *result, NSError *error);

@protocol SPSDKManagerDelegate <NSObject>

@required
- (void)didLoginRequestReceivedWithResult:(SPSDKLoginResult*)result withError:(NSError*)error;

@end

@interface SPSDKManager : NSObject

@property (nonatomic, retain) NSObject<SPSDKManagerDelegate> *delegate;

+ (SPSDKManager *) sharedInstance;
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation;
- (void)loginWithCompletionHandler:(SPSDKLoginResultHandler)completionHandler;

@end
