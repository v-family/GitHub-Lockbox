//
//  SDKErrors.h
//  SaasPassSDK
//
//  Created by Ljupco Gjorgjiev on 11/11/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#ifndef SDKErrors_h
#define SDKErrors_h

typedef enum SPSdkErrorCode
{
    /// Invalid Call: SP app detected invalid call.
    SPSdkErrorCodeInvalidCall = 3200,
    
    ///New version: SDK detected unsupported new version.
    SPSdkErrorCodeUnsupportedNewVersion = 3201,
    
    /// The SAASPASS App is not installed. It must be installed to send text.
    SPSdkErrorCodeSPAppNotFound = 3202,
    
    ///App key not exist: valid call, but user doesn’t have such application on SP.
    SPSdkErrorAppKeyNotExists = 3203,
    
    ///Unknown: if real reason not known.
    SPSdkErrorCodeUnknown = 3204
    
} SPSdkErrorCode;

#endif /* SDKErrors_h */
