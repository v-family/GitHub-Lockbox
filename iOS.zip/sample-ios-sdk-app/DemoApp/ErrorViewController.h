//
//  ErrorViewController.h
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/18/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ErrorViewController : UIViewController {
    IBOutlet UIButton *btnGoBack;
    IBOutlet UIButton *btnDownload;
    IBOutlet UILabel *lblErrorMessage;
}

@property(nonatomic, retain) NSString *errorMsg;
@property(nonatomic) NSInteger errorCode;

-(void)setErrorMessage:(NSString*)errorMessage;

@end
