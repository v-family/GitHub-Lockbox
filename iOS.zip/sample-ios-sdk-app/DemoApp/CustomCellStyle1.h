//
//  CustomCellStyle1.h
//  SPLogin
//
//  Created by SP Developer on 12/7/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellStyle1 : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *label;


@end
