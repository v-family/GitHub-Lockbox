//
//  JSONParser.h
//  SolidPassEngine
//
//  Created by aradiom on 8/28/13.
//  Copyright (c) 2013 Aradiom Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONKit.h"

@interface JSONParser : NSObject

+ (id)deserializeString:(NSString *)stringToDeserialize;
+ (NSString *)serializeDictionary:(NSDictionary *)dictionaryToSerialize;
+ (NSString *)serializeArray:(NSArray *)arrayToSerialize;

@end
