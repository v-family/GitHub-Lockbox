//
//  MainScreenViewController.h
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/18/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainScreenViewController : UIViewController

@end
