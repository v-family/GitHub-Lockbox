//
//  SuccessfulLoginViewController.m
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/17/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import "SuccessfulLoginViewController.h"
#import "MainScreenViewController.h"

@implementation SuccessfulLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self performSelector:@selector(openMainViewController) withObject:nil afterDelay:3.0];
    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)openMainViewController
{    
     UIViewController *controller =  [self.storyboard instantiateViewControllerWithIdentifier:@"MainScreenViewController"];
     [self.navigationController pushViewController:controller animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
