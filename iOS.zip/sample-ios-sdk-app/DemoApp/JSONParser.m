//
//  JSONParser.m
//  SolidPassEngine
//
//  Created by aradiom on 8/28/13.
//  Copyright (c) 2013 Aradiom Co. Ltd. All rights reserved.
//

#import "JSONParser.h"

#define TRACE_RUNTIME_CODEFLOW()    NSStringFromSelector(_cmd)

@implementation JSONParser

+ (id)deserializeString:(NSString *)stringToDeserialize
{
    NSError *error = nil;
    
    CFDictionaryRef deserializedResult = (CFDictionaryRef)[stringToDeserialize
                                                           objectFromJSONStringWithParseOptions:JKParseOptionNone
                                                           error:&error];
    [[self class] handleError:error];
    
    return (id)deserializedResult;
}

+ (void)handleError:(NSError *)error
{
    if(error)
    {
        CFMutableStringRef traceLog = (CFMutableStringRef)[error description];
        CFStringAppend(traceLog,
                       (CFStringRef)TRACE_RUNTIME_CODEFLOW());
        
    }
}

+ (NSString *)serializeDictionary:(NSDictionary *)dictionaryToSerialize
{
    NSError *error = nil;
    
    NSString *serializedResult = [dictionaryToSerialize JSONStringWithOptions:JKParseOptionNone
                                                                        error:&error];
    [[self class] handleError:error];
    return serializedResult;
}

+ (NSString *)serializeArray:(NSArray *)arrayToSerialize
{
    NSError *error = nil;
    
    NSString *serializedResult = [arrayToSerialize JSONStringWithOptions:JKParseOptionNone
                                                                   error:&error];
    [[self class] handleError:error];
    return serializedResult;
}

@end
