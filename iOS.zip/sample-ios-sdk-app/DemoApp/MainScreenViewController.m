//
//  MainScreenViewController.m
//  DemoApp
//
//  Created by Ljupco Gjorgjiev on 11/18/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import "MainScreenViewController.h"
#import "AppDelegate.h"
#import "CustomCellStyle1.h"
#import "JSONParser.h"
#import "RMYouTubeExtractor.h"
#import <MediaPlayer/MPMoviePlayerViewController.h>
#import <MediaPlayer/MPMoviePlayerController.h>

@implementation MainScreenViewController {
    NSArray *items;
    NSMutableDictionary *images;
    UIRefreshControl *refreshControl;
    __weak IBOutlet UITableView *table;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(mediaPlayerDoneButtonClick:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:nil];
    refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(refreshVideos) forControlEvents:UIControlEventValueChanged];
    [table addSubview:refreshControl];
    
    [self prepareVideos];
    images = [NSMutableDictionary dictionary];
}

- (void)prepareVideos {
    NSURL *url = [NSURL URLWithString:@"https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UC7rOgFOnh9aLx4wSsuAasDQ&maxResults=50&type=video&key=AIzaSyBxE2dMk-A0Vz5pHOmEs-N6L7DkQSIQL8o"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    NSURLResponse *response;
    NSError *error = nil;
    //send it synchronous
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    
    NSDictionary *responseDict = [JSONParser deserializeString:responseString];
    items = [responseDict objectForKey:@"items"];
}

- (void)refreshVideos {
    [self prepareVideos];
    [table reloadData];
    if (refreshControl) {
        [refreshControl performSelector:@selector(endRefreshing) withObject:nil afterDelay:0.01];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)logoutAction:(id)sender {
    [APP_DELEGATE setLoggedIn:NO];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // There is only one section.
    if (items) {
        table.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        table.backgroundView = nil;
        return 1;
    } else {
        // Display a message when the table is empty
        UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
        
        messageLabel.text = @"No data is currently available.\nCheck your internet connectivity and pull down to refresh.";
        messageLabel.textColor = [UIColor blackColor];
        messageLabel.numberOfLines = 0;
        messageLabel.textAlignment = NSTextAlignmentCenter;
        messageLabel.font = [UIFont systemFontOfSize:17];
        [messageLabel sizeToFit];
        
        table.backgroundView = messageLabel;
        table.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return 0;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of time zone names.
    return items.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CustomCellStyle1 *cell = [tableView dequeueReusableCellWithIdentifier:@"tutorialRow"];
    NSDictionary *item = items[indexPath.row];
    NSString *iconUrl = item[@"snippet"][@"thumbnails"][@"medium"][@"url"];
    NSString *rowKey = [NSString stringWithFormat:@"%ld", (long)indexPath.row];
    
    if ([images objectForKey:rowKey]) {
        NSData *imageData = [images objectForKey:rowKey];
        [cell.image setImage:[UIImage imageWithData:imageData]];

    } else {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:iconUrl]];
            dispatch_async(dispatch_get_main_queue(), ^{
                if(imageData) {
                    [images setObject:imageData forKey:rowKey];
                    [cell.image setImage:[UIImage imageWithData:imageData]];
                }
            });
        });
    }
    [cell.label setText:item[@"snippet"][@"title"]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    NSDictionary *item = items[indexPath.row];
    [[RMYouTubeExtractor sharedInstance] extractVideoForIdentifier:item[@"id"][@"videoId"]
                                                        completion:^(NSDictionary *videoDictionary, NSError *error) {
                                                            if (!error) {
                                                                NSURL *videoUrl = videoDictionary[[NSNumber numberWithLong:RMYouTubeExtractorVideoQualityHD720]];
                                                                if (!videoUrl) {
                                                                    videoUrl = videoDictionary[[NSNumber numberWithLong:RMYouTubeExtractorVideoQualityMedium360]];
                                                                }
                                                                if (!videoUrl) {
                                                                    videoUrl = videoDictionary[[NSNumber numberWithLong:RMYouTubeExtractorVideoQualitySmall240]];
                                                                }
                                                                if (videoUrl) {
                                                                    [self playVideo:videoUrl];
                                                                } else {
                                                                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
                                                                                                                        message:@"No data is currently available.\nCheck your internet connectivity and try again."
                                                                                                                       delegate:nil
                                                                                                              cancelButtonTitle:nil
                                                                                                              otherButtonTitles:@"OK", nil];
                                                                    [alertView show];
                                                                }
                                                            } else {
                                                                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
                                                                                                                    message:@"No data is currently available.\nCheck your internet connectivity and try again."
                                                                                                                   delegate:nil
                                                                                                          cancelButtonTitle:nil
                                                                                                          otherButtonTitles:@"OK", nil];
                                                                [alertView show];
                                                            }
                                                        }];
}

-(void)playVideo:(NSURL *)videoUrl {
    MPMoviePlayerViewController *mpViewController = [[MPMoviePlayerViewController alloc] initWithContentURL:videoUrl];
    mpViewController.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    [self.navigationController presentViewController:mpViewController animated:YES completion:nil];
    [[mpViewController moviePlayer] play];
}

- (void)mediaPlayerDoneButtonClick:(NSNotification*)notification {
    NSNumber *reason = [notification.userInfo objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey];
    if ([reason intValue] == MPMovieFinishReasonUserExited) {
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }
}

@end
