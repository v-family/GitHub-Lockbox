//
//  SPSdkManager.h
//  SaasPassSDK
//
//  Created by Ljupco Gjorgjiev on 10/2/15.
//  Copyright (c) 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ResultManager.h"
#import "SDKErrors.h"

@protocol SPSdkManagerDelegate <NSObject>
@optional
- (void)receivedResult:(ResultManager*)result withError:(NSError*)error;
@end

@interface SPSdkManager : NSObject
@property (nonatomic, retain)  NSObject<SPSdkManagerDelegate> *delegate;


+ (SPSdkManager *) sharedInstance;
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation;
- (void)loginWithSaasPass;

@end
