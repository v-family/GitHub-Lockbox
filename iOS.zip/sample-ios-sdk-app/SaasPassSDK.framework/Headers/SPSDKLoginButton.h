//
//  SPSDKLoginButton.h
//  SaasPassSDK
//
//  Created by Ljupco Gjorgjiev on 11/9/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface SPSDKLoginButton : UIButton

@end
