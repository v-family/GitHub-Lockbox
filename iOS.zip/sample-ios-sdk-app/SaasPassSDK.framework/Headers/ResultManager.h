//
//  ResultManager.h
//  SaasPassSDK
//
//  Created by Ljupco Gjorgjiev on 11/2/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ResultManager : NSObject

@property (retain, nonatomic) NSString *trackerID;
@property (retain, nonatomic) NSString *userName;

- (id)initWithDictionary:(NSDictionary *)dictionary;
- (BOOL)isCanceled;

@end
