"""Module containing the pages available for interaction."""
