# Welcome to Lockbox's extension documentation!

You can read this documentation [online][online-docs-link] or by browsing the
[`docs` directory on GitHub][repo-docs-link].

[online-docs-link]: https://mozilla-lockbox.github.io/lockbox-extension/
[repo-docs-link]: https://github.com/mozilla-lockbox/lockbox-extension/tree/master/docs
