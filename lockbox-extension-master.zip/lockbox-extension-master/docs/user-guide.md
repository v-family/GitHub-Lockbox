# Lockbox User Guide

First things first, [install the extension](developer/install.md).

## Commands

* `Ctrl-Shift-L`: open Lockbox editor (item management)
