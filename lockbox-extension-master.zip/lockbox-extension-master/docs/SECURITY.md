# Mozilla Security #

- Mozilla cares about privacy and security. For more information please see: https://www.mozilla.org/security/

- If you believe that you've found a security vulnerability, please report it by sending email to the addresses: security@mozilla.org and lockbox-dev@mozilla.com
