//
//  SPSDKLoginButton.h
//  SaasPassSDK
//
//  Created by Ljupco Gjorgjiev on 11/9/15.
//  Copyright © 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@protocol SPSDKLoginButtonDelegate;
@class SPSDKLoginResult;

@interface SPSDKLoginButton : UIButton

@property (weak, nonatomic) IBOutlet id<SPSDKLoginButtonDelegate> delegate;

@end

@protocol SPSDKLoginButtonDelegate <NSObject>

@required
- (void)loginButton:(SPSDKLoginButton *)loginButton didCompleteWithResult:(SPSDKLoginResult*)result withError:(NSError*)error;

@end

