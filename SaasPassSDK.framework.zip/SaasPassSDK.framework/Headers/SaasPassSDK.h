//
//  SaasPassSDK.h
//  SaasPassSDK
//
//  Created by Ljupco Gjorgjiev on 9/28/15.
//  Copyright (c) 2015 Ljupco Gjorgjiev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SaasPassSDK/SPSDKManager.h>
#import <SaasPassSDK/SPSDKLoginButton.h>
#import <SaasPassSDK/SPSDKLoginResult.h>

#define DEVICE_OS                                                           [[[UIDevice currentDevice] systemVersion] floatValue]
#define IS_IPAD                                                             UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad
#define IS_RETINA                                                           ([[UIScreen mainScreen] respondsToSelector:@selector(displayLinkWithTarget:selector:)] && ([UIScreen mainScreen].scale >= 2.0))
#define IS_IPAD_NONRETINA                                                   IS_IPAD && !IS_RETINA
#define IS_IOS7_OR_GREATER                                                  [[[UIDevice currentDevice] systemVersion] floatValue] >= 7
//! Project version number for SaasPassSDK.
FOUNDATION_EXPORT double SaasPassSDKVersionNumber;

//! Project version string for SaasPassSDK.
FOUNDATION_EXPORT const unsigned char SaasPassSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SaasPassSDK/PublicHeader.h>
