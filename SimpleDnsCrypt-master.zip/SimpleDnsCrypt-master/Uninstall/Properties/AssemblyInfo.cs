﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Uninstall")]
[assembly: AssemblyDescription("Uninstaller for Simple DNSCrypt")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Uninstall")]
[assembly: AssemblyCopyright("Copyright © 2015 - 2019 Christian Hermann")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("1a9ca4fe-bdd5-4d7c-a86a-7ed503974718")]
[assembly: AssemblyVersion("0.2.4")]
[assembly: AssemblyFileVersion("0.2.4")]
