# Contributors #

Those listed below have contributed to `SimpleDnsCrypt`, and are the copyright holders. See the `LICENSE.md` file for details. Contributors are listed in chronological order:

 * @bitbeans - Christian Hermann <c.hermann@bitbeans.de>
 * @christantoan
 * @tuphamnguyen
 * @thedroidgeek
 * @didihu
 * @jerryhou85
 * @rugk - <rugk@posteo.de>
 * Vlad - <elfriob@ya.ru>
 * @emirgian
 * @bcien
 * @eson57
 * @simonclausen
 * @ShellAddicted
 * @robin98
 * @pablomh
 * @rddim
 * @porsche613
 * @socrat3z
 * @niikoo
 * @bungoume
 * Esmail EL BoB - <esmailelbob01124320019@gmail.com>
 * @ukind
 * @Mongogamer
 * @Celonfix - <Celonfix@protonmail.com>
