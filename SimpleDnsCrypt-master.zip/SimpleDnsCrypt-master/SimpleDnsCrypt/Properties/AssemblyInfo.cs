﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
[assembly: AssemblyTitle("Simple DnsCrypt")]
[assembly: AssemblyDescription("Simple management tool for dnscrypt-proxy")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Simple DnsCrypt")]
[assembly: AssemblyCopyright("Copyright © 2015 - 2019 Christian Hermann")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(
	ResourceDictionaryLocation.None,
	ResourceDictionaryLocation.SourceAssembly
)]
[assembly: AssemblyVersion("0.6.4")]
[assembly: AssemblyFileVersion("0.6.4")]
