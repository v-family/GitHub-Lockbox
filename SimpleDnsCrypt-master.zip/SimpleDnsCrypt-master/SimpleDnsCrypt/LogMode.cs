﻿namespace SimpleDnsCrypt
{
	public static class LogMode
	{
		public static bool Debug { get; set; } = false;
		public static bool Error { get; set; } = true;
		public static bool Warn { get; set; } = true;
	}
}
