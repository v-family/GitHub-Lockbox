﻿namespace SimpleDnsCrypt.Windows
{
	public partial class BaseWindow
	{
		public BaseWindow()
		{
			InitializeComponent();
		}
	}
}
