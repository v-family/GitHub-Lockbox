﻿namespace SimpleDnsCrypt.Windows
{
	public partial class BaseDialogWindow
	{
		public BaseDialogWindow()
		{
			InitializeComponent();
		}
	}
}
