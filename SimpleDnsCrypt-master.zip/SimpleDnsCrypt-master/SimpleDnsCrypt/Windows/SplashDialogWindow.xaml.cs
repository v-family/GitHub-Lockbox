﻿namespace SimpleDnsCrypt.Windows
{
	public partial class SplashDialogWindow
	{
		public SplashDialogWindow()
		{
			InitializeComponent();
		}
	}
}
