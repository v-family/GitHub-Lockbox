﻿namespace SimpleDnsCrypt.Windows
{
	public partial class BaseMessageDialogWindow 
	{
		public BaseMessageDialogWindow()
		{
			InitializeComponent();
		}
	}
}
