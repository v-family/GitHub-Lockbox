﻿namespace SimpleDnsCrypt.Windows
{
	public partial class BaseTrayWindow
	{
		public BaseTrayWindow()
		{
			InitializeComponent();
		}
	}
}
