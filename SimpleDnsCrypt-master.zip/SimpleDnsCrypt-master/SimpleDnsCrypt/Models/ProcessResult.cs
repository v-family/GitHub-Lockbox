﻿namespace SimpleDnsCrypt.Models
{
	public class ProcessResult
	{
		public bool Success { get; set; }
		public string StandardError { get; set; }
		public string StandardOutput { get; set; }
	}
}
