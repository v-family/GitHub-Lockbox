﻿namespace SimpleDnsCrypt.Models
{
	public class ValueDescription
	{
		public object Description { get; set; }
		public object Value { get; set; }
	}
}
