﻿namespace SimpleDnsCrypt.Models
{
	public class Rule
	{
		public string Key { get; set; }
		public string Value { get; set; }
	}
}
