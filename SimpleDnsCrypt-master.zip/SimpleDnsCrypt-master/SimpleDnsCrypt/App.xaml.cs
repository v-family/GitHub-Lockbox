﻿using System.Windows;

namespace SimpleDnsCrypt
{
	public partial class App : Application
	{
		public App()
		{
			InitializeComponent();
		}
	}
}
