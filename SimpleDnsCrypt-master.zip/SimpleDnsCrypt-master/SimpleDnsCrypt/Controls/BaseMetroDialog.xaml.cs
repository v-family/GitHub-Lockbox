﻿namespace SimpleDnsCrypt.Controls
{
	public partial class BaseMetroDialog
	{
		public BaseMetroDialog()
		{
			InitializeComponent();
		}
	}
}
